/* eslint-disable vue/valid-v-for */
<template>
  <div class="my-main">
    <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      @open="handleOpen"
      @close="handleClose"
      router
      v-for="(item,index) in this.$router.options.routes" v-bind:key="index">
      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>{{item.name}}</span>
        </template>
        <el-menu-item-group >
          <el-menu-item :index="it.path"  v-for="(it,ind) in item.children"  v-bind:key="ind">{{it.name}}</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>`
    <div class="my-content">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{this.$route.name }}</el-breadcrumb-item>
      </el-breadcrumb>
      <router-view></router-view>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      url: [
        {
          path: '/',
          name: '目录'
        }
      ]
    }
  },
  methods: {
    handleOpen (key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose (key, keyPath) {
      console.log(key, keyPath)
    },
    click () {
      console.log(this.$router)
    }
  }
}
</script>
<style scoped>
.my-main {
  display: flex;
  min-height: calc(100vh - 100px);
}
.my-aside {
  width: 200px;
  border-right: 1px solid #666;
  min-height: calc(100vh - 100px);
}
.el-menu-vertical-demo{
  width: 200px;
}
.my-content {
  flex: 1;
  padding: 0 10px;
  min-height: calc(100vh - 100px);
  margin:20px 0;
}
</style>
