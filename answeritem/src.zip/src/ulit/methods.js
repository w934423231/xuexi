
import fetch from './requst'
import requsturl from './requsturl'

// 查看商品数据

export function shopdataselect () {
  return fetch({
    url: requsturl.path + '/shopdata/select',
    method: 'get'
  })
}

// 添加商品数据

export function shopdatainert (data) {
  return fetch({
    url: requsturl.path + '/shopdata/insert',
    method: 'post',
    data
  })
}

// 更改商品数据

export function shopdataupdata (data) {
  return fetch({
    url: requsturl.path + '/shopdata/updata',
    method: 'post',
    data
  })
}

// 商品数据删除

export function shopdatadelete (data) {
  return fetch({
    url: requsturl.path + '/shopdata/delete',
    method: 'post',
    data
  })
}
// 查看商品数据类型

export function selectshoptype () {
  return fetch({
    url: requsturl.path + '/shoptype/select',
    method: 'get'
  })
}

// 添加商品数据类型

export function addshoptype (data) {
  return fetch({
    url: requsturl.path + '/shoptype/append',
    method: 'post',
    data
  })
}

// 更改商品数据类型

export function updateshoptype (data) {
  return fetch({
    url: requsturl.path + '/shoptype/update',
    method: 'post',
    data
  })
}

// 删除商品数据类型

export function delshoptype (data) {
  return fetch({
    url: requsturl.path + '/shoptype/delete',
    method: 'post',
    data
  })
}
