
let arr = [
  {
    path: 'http://localhost:8000',
    img: 'http://192.12.34.63:8080'
  },
  {
    path: 'http://www.testapi.com',
    img: 'http://192.12.24.63:8080'
  },
  {
    path: 'http://www.uatapi.com',
    img: 'http://192.12.24.63:8080'
  },
  {
    path: 'http://www.api.com',
    img: 'http://192.12.24.63:8080'
  }
]
const index = 0
export default arr[index]
