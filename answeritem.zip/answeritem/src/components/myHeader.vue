<template>
    <div class="my-header">
        这个是header页面
    </div>
</template>
<script>
export default {}
</script>
<style scoped>
.my-header{
    height: 100px;
    border-bottom: 1px solid #666;
}
</style>
